package spring.exception;

public class IdPasswordNotMatchingException extends RuntimeException{

}
