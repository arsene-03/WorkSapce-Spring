package spring.exception;

public class MemberNotFoundException extends RuntimeException{

}
